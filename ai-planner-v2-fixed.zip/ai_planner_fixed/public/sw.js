const CACHE = 'ai-planner-v2-static'
const RUNTIME = 'ai-planner-v2-runtime'
const CORE = ['/', '/offline/', '/manifest.json', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/icon-maskable-512.png']

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()))
})
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => ![CACHE,RUNTIME].includes(k)).map(k => caches.delete(k)))).then(() => self.clients.claim()))
})

function isStaticAsset(url) { return /\.(?:js|css|woff2|png|jpg|jpeg|webp|svg|ico)$/.test(url.pathname) }
self.addEventListener('fetch', event => {
  const request = event.request
  if (request.method !== 'GET') return
  const url = new URL(request.url)
  if (url.origin !== self.location.origin) return
  if (isStaticAsset(url)) {
    event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => { const copy=response.clone(); caches.open(RUNTIME).then(c=>c.put(request,copy)); return response }).catch(()=>caches.match('/offline/'))))
    return
  }
  event.respondWith(fetch(request).then(response => { if (response.ok && request.mode === 'navigate') { const copy=response.clone(); caches.open(RUNTIME).then(c=>c.put(request,copy)) } return response }).catch(() => caches.match(request).then(cached => cached || caches.match('/offline/'))))
})

self.addEventListener('message', event => { if (event.data?.type === 'SKIP_WAITING') self.skipWaiting() })
self.addEventListener('notificationclick', event => { event.notification.close(); event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list => list[0]?.focus?.() || clients.openWindow('/'))) })
self.addEventListener('push', event => {
  let data = {}; try { data = event.data?.json() || {} } catch { data = { body: event.data?.text() || '' } }
  event.waitUntil(self.registration.showNotification(data.title || 'AI Planner', { body:data.body || 'یادآوری جدید', icon:'/icons/icon-192.png', badge:'/icons/icon-192.png', tag:data.tag || 'ai-planner' }))
})
