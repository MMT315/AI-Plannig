# AI Planner 2.0

PWA شخصی و local-first برای مدیریت وظایف، اهداف، تقویم و دستیار AI.

## ویژگی‌ها
- Next.js 14 App Router + Static Export
- TypeScript strict
- Tailwind CSS 3
- IndexedDB نسخه‌دار با migration پایه
- فارسی RTL و انگلیسی LTR
- تقویم شمسی با `jalaali-js`
- Task / Goal / Calendar views
- Atria و GapGPT با API key محلی
- Web Audio reminders
- Service Worker و offline fallback
- JSON backup / restore
- Cloudflare Pages compatible

## اجرا

```bash
npm install
npm run typecheck
npm run build
```

خروجی در `out/` قرار می‌گیرد.

## استقرار Cloudflare Pages

Build command:

```text
npm run build
```

Output directory:

```text
out
```

API key در IndexedDB مرورگر ذخیره می‌شود و به عنوان secret server-side محسوب نمی‌شود. برای استفاده روی دستگاه شخصی مناسب است؛ برای محصول چندکاربره باید proxy/backend امن اضافه شود.
