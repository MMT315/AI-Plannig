import type { Metadata, Viewport } from 'next'
import './globals.css'
import { AppProvider } from '@/lib/ui'

export const metadata: Metadata = {
  title: 'AI Planner — برنامه‌ریز هوشمند',
  description: 'برنامه‌ریز شخصی آفلاین با IndexedDB و دستیار هوش مصنوعی',
  robots: { index: false, follow: false },
  manifest: '/manifest.json',
  icons: { icon: '/icons/favicon.ico', apple: '/icons/icon-192.png' },
}

export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', themeColor: '#7c5cff' }

const themeScript = `(() => { try { const t=localStorage.getItem('ai-planner-theme')||'modern'; document.documentElement.setAttribute('data-theme',t); const l=localStorage.getItem('ai-planner-lang')||'fa'; document.documentElement.lang=l; document.documentElement.dir=l==='fa'?'rtl':'ltr'; } catch(e){} })()`

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fa" dir="rtl" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{__html:themeScript}}/><meta name="mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/></head><body><AppProvider>{children}</AppProvider><script dangerouslySetInnerHTML={{__html:`if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}))}`}}/></body></html>
}
