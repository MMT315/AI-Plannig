'use client'
import Link from 'next/link'
export default function Offline(){return <main className="splash"><div className="splash-card card"><div className="logo-mark large">⌁</div><h1>آفلاین هستی</h1><p>داده‌های محلی برنامه همچنان در دسترس‌اند. بعد از اتصال دوباره، صفحه را تازه کن.</p><Link className="btn btn-primary btn-md" href="/" style={{marginTop:20}}>بازگشت به برنامه</Link></div></main>}
