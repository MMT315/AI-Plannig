'use client'
import { useEffect, useState } from 'react'
import { Plus } from 'lucide-react'
import { Button, Card, Modal, PageHeader, TaskCard, TaskForm } from '@/lib/ui'
import { deleteTask, getTasksForDate, isoDate, saveTask, type Task } from '@/lib/core'
export default function Daily(){const [tasks,setTasks]=useState<Task[]>([]);const[open,setOpen]=useState(false);async function load(){setTasks(await getTasksForDate(isoDate()))}useEffect(()=>{load().catch(console.error)},[]);return <><PageHeader title="امروز" description="تمرکز روی کارهای همین روز" action={<Button onClick={()=>setOpen(true)}><Plus size={18}/> وظیفه جدید</Button>}/>{tasks.length?<div className="task-list">{tasks.map(t=><TaskCard key={t.id} task={t} onToggle={async x=>{await saveTask(x);load()}} onDelete={async x=>{await deleteTask(x.id);load()}}/>)}</div>:<Card className="empty">برای امروز وظیفه‌ای نداری.</Card>}<Modal open={open} title="وظیفه جدید" onClose={()=>setOpen(false)}><TaskForm onSave={async t=>{await saveTask(t);await load()}} onCancel={()=>setOpen(false)}/></Modal></>}
