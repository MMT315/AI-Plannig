'use client'
import { useEffect,useState } from 'react'
import { Card, PageHeader, TaskCard } from '@/lib/ui'
import { getAllTasks, isoDate, type Task } from '@/lib/core'
export default function Weekly(){const[tasks,setTasks]=useState<Task[]>([]);useEffect(()=>{getAllTasks().then(setTasks).catch(console.error)},[]);const days=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()+i);return d});return <><PageHeader title="برنامه هفتگی" description="نمای هفت روز آینده"/><div className="calendar-week">{days.map(d=>{const key=isoDate(d);const list=tasks.filter(t=>t.startDate===key);return <Card className="week-col" key={key}><h3>{d.toLocaleDateString('fa-IR',{weekday:'long',month:'long',day:'numeric'})}</h3>{list.length?<div className="task-list">{list.map(t=><TaskCard key={t.id} task={t} onToggle={()=>{}}/>)}</div>:<div className="empty">خالی</div>}</Card>})}</div></>}
