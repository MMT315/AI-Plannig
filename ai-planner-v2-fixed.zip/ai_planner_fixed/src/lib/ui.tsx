'use client'

import { FormEvent, ReactNode, useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Bell, CalendarDays, CheckCircle2, ChevronLeft, ChevronRight, ClipboardList, Clock3, Flag, Goal, Home, Menu, Moon, Plus, Settings, Sparkles, Sun, Target, Trash2, X } from 'lucide-react'
import { cn, type Goal as GoalType, type Task, type ThemeName, type Lang, playSound, setSetting } from './core'

export function Logo() {
  return <Link href="/" className="flex items-center gap-3 font-black tracking-tight"><span className="logo-mark"><Sparkles size={20}/></span><span>AI Planner</span></Link>
}

export function SplashScreen() {
  return <main className="splash"><div className="orb orb-a"/><div className="orb orb-b"/><div className="splash-card"><div className="logo-mark large"><Sparkles size={32}/></div><h1>AI Planner</h1><p>برنامه‌ریز هوشمند شخصی</p><div className="loading-line"><span/></div></div></main>
}

export function Button({ children, variant='primary', size='md', className, type='button', onClick, disabled=false }: { children: ReactNode; variant?: 'primary'|'secondary'|'ghost'|'danger'|'outline'; size?: 'sm'|'md'|'lg'; className?: string; type?: 'button'|'submit'|'reset'; onClick?: () => void; disabled?: boolean }) {
  return <button type={type} disabled={disabled} onClick={() => { if (!disabled) { playSound('gentle'); onClick?.() } }} className={cn('btn', `btn-${variant}`, `btn-${size}`, className)}>{children}</button>
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement> & { label?: string }) {
  const { label, id, ...rest } = props
  return <label className="field">{label && <span>{label}</span>}<input id={id} {...rest}/></label>
}
export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string }) {
  const { label, id, ...rest } = props
  return <label className="field">{label && <span>{label}</span>}<textarea id={id} {...rest}/></label>
}

export function Card({ children, className='' }: { children: ReactNode; className?: string }) { return <section className={cn('card', className)}>{children}</section> }
export function Badge({ children, tone='default' }: { children: ReactNode; tone?: 'default'|'success'|'warning'|'danger' }) { return <span className={`badge badge-${tone}`}>{children}</span> }

const nav = [
  ['/','خانه',Home], ['/daily','امروز',ClipboardList], ['/weekly','هفتگی',CalendarDays], ['/monthly','ماهانه',CalendarDays], ['/goals','اهداف',Target], ['/ai','دستیار AI',Sparkles], ['/settings','تنظیمات',Settings],
] as const

export function AppShell({ children, lang='fa', theme='modern', onLangChange, onThemeChange }: { children: ReactNode; lang?: Lang; theme?: ThemeName; onLangChange?: (lang: Lang) => void; onThemeChange?: (theme: ThemeName) => void }) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)
  useEffect(() => { setMobileOpen(false) }, [pathname])
  return <div className="app-shell">
    <header className="topbar"><button className="icon-btn mobile-only" aria-label="منو" onClick={() => setMobileOpen(v=>!v)}><Menu size={22}/></button><Logo/><div className="top-actions"><button className="icon-btn" aria-label="اعلان‌ها"><Bell size={20}/></button><select aria-label="زبان" value={lang} onChange={e => onLangChange?.(e.target.value as Lang)}><option value="fa">FA</option><option value="en">EN</option></select><button className="icon-btn" aria-label="تغییر تم" onClick={() => onThemeChange?.(theme === 'light' ? 'dark' : 'light')}>{theme === 'light' ? <Moon size={20}/> : <Sun size={20}/>}</button></div></header>
    <div className="shell-body">
      <aside className={cn('sidebar', mobileOpen && 'open')}><div className="sidebar-head"><span>منوی برنامه</span><button className="icon-btn mobile-only" onClick={() => setMobileOpen(false)} aria-label="بستن"><X size={18}/></button></div>{nav.map(([href,label,Icon]) => <Link key={href} href={href} className={cn('nav-link', pathname === href && 'active')}><Icon size={19}/><span>{label}</span></Link>)}<div className="sidebar-footer"><small>AI Planner v2.0</small></div></aside>
      <main className="content">{children}</main>
    </div>
  </div>
}

export function PageHeader({ title, description, action }: { title: string; description?: string; action?: ReactNode }) { return <div className="page-header"><div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div> }

export function StatCard({ icon, label, value, hint }: { icon: ReactNode; label: string; value: string|number; hint?: string }) { return <Card className="stat-card"><div className="stat-icon">{icon}</div><div><div className="muted">{label}</div><strong>{value}</strong>{hint && <small>{hint}</small>}</div></Card> }

export function TaskCard({ task, onToggle, onDelete }: { task: Task; onToggle: (task: Task) => void; onDelete?: (task: Task) => void }) {
  const done = task.status === 'done'
  return <Card className={cn('task-card', done && 'completed')}><button className="check-btn" aria-label={done ? 'بازگردانی وظیفه' : 'تکمیل وظیفه'} onClick={() => onToggle({ ...task, status: done ? 'pending' : 'done', completedAt: done ? undefined : new Date().toISOString(), updatedAt: new Date().toISOString() })}>{done ? <CheckCircle2/> : <span/>}</button><div className="task-main"><div className="task-title-row"><h3>{task.title || 'بدون عنوان'}</h3><Badge tone={task.priority === 'urgent' ? 'danger' : task.priority === 'high' ? 'warning' : 'default'}>{task.priority}</Badge></div>{task.description && <p>{task.description}</p>}<div className="task-meta">{task.startTime && <span><Clock3 size={14}/>{task.startTime}</span>}<span><Flag size={14}/>{task.type}</span>{task.repeat !== 'none' && <span>تکرار: {task.repeat}</span>}</div></div>{onDelete && <button className="icon-btn danger-icon" onClick={() => onDelete(task)} aria-label="حذف"><Trash2 size={18}/></button>}</Card>
}

export function GoalCard({ goal, onDelete }: { goal: GoalType; onDelete?: (goal: GoalType) => void }) { return <Card className="goal-card"><div className="goal-head"><div className="goal-icon"><Goal size={20}/></div>{onDelete && <button className="icon-btn" onClick={() => onDelete(goal)} aria-label="حذف"><Trash2 size={17}/></button>}</div><h3>{goal.title || 'بدون عنوان'}</h3><p>{goal.description}</p><div className="progress"><span style={{ width: `${Math.max(0, Math.min(100, goal.progress))}%` }}/></div><div className="goal-foot"><span>{goal.progress}%</span><Badge tone={goal.status === 'completed' ? 'success' : 'default'}>{goal.status}</Badge></div></Card> }

export function Modal({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => { if (!open) return; const old = document.body.style.overflow; document.body.style.overflow = 'hidden'; const key = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', key); return () => { document.body.style.overflow = old; window.removeEventListener('keydown', key) } }, [open, onClose])
  if (!open) return null
  return <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.currentTarget === e.target) onClose() }}><section className="modal" role="dialog" aria-modal="true" aria-label={title}><header><h2>{title}</h2><button className="icon-btn" onClick={onClose} aria-label="بستن"><X/></button></header>{children}</section></div>
}

export function TaskForm({ initial, onSave, onCancel }: { initial?: Partial<Task>; onSave: (task: Task) => Promise<void>; onCancel: () => void }) {
  const [title,setTitle]=useState(initial?.title??''); const [date,setDate]=useState(initial?.startDate??new Date().toISOString().slice(0,10)); const [time,setTime]=useState(initial?.startTime??''); const [priority,setPriority]=useState<Task['priority']>(initial?.priority??'medium'); const [desc,setDesc]=useState(initial?.description??''); const [saving,setSaving]=useState(false)
  async function submit(e: FormEvent) { e.preventDefault(); if (!title.trim()) return; setSaving(true); try { const now=new Date().toISOString(); await onSave({ id: initial?.id ?? `task_${crypto.randomUUID()}`, title:title.trim(), description:desc.trim(), type:initial?.type??'daily', priority, status:initial?.status??'pending', startDate:date, startTime:time, endTime:initial?.endTime??'', reminderEnabled:initial?.reminderEnabled??false, reminderMinutesBefore:initial?.reminderMinutesBefore??10, alarmType:initial?.alarmType??'gentle', repeat:initial?.repeat??'none', goalId:initial?.goalId, tags:initial?.tags??[], createdAt:initial?.createdAt??now, updatedAt:now, completedAt:initial?.completedAt }); onCancel() } finally { setSaving(false) } }
  return <form onSubmit={submit} className="form-stack"><Input label="عنوان" value={title} onChange={e=>setTitle(e.target.value)} autoFocus placeholder="مثلاً: مطالعه فصل اول"/><div className="form-grid"><Input label="تاریخ میلادی" type="date" value={date} onChange={e=>setDate(e.target.value)}/><Input label="ساعت" type="time" value={time} onChange={e=>setTime(e.target.value)}/></div><label className="field"><span>اولویت</span><select value={priority} onChange={e=>setPriority(e.target.value as Task['priority'])}><option value="low">کم</option><option value="medium">متوسط</option><option value="high">زیاد</option><option value="urgent">فوری</option></select></label><label className="field"><span>توضیحات</span><textarea value={desc} onChange={e=>setDesc(e.target.value)} rows={4}/></label><div className="form-actions"><Button variant="secondary" onClick={onCancel}>انصراف</Button><Button type="submit" disabled={saving}>{saving?'در حال ذخیره...':'ذخیره'}</Button></div></form>
}

export function GoalForm({ initial, onSave, onCancel }: { initial?: Partial<GoalType>; onSave: (goal: GoalType) => Promise<void>; onCancel: () => void }) {
  const [title,setTitle]=useState(initial?.title??''); const [desc,setDesc]=useState(initial?.description??''); const [progress,setProgress]=useState(String(initial?.progress??0)); const [saving,setSaving]=useState(false)
  async function submit(e: FormEvent) { e.preventDefault(); if (!title.trim()) return; setSaving(true); try { const now=new Date().toISOString(); await onSave({ id:initial?.id??`goal_${crypto.randomUUID()}`, title:title.trim(), description:desc.trim(), category:initial?.category??'عمومی', targetDate:initial?.targetDate??'', progress:Math.max(0,Math.min(100,Number(progress)||0)), milestones:initial?.milestones??[], status:initial?.status??'active', color:initial?.color??'#7c5cff', createdAt:initial?.createdAt??now, updatedAt:now }); onCancel() } finally { setSaving(false) } }
  return <form onSubmit={submit} className="form-stack"><Input label="عنوان هدف" value={title} onChange={e=>setTitle(e.target.value)} autoFocus placeholder="مثلاً: یادگیری TypeScript"/><Textarea label="توضیحات" value={desc} onChange={e=>setDesc(e.target.value)} rows={3}/><Input label="پیشرفت (درصد)" type="number" min={0} max={100} value={progress} onChange={e=>setProgress(e.target.value)}/><div className="form-actions"><Button variant="secondary" onClick={onCancel}>انصراف</Button><Button type="submit" disabled={saving}>{saving?'در حال ذخیره...':'ذخیره'}</Button></div></form>
}

export function useAppSettings() {
  const [settings,setSettings] = useState<{lang:Lang;theme:ThemeName}>({lang:'fa',theme:'modern'})
  useEffect(()=>{ import('./core').then(({getSettings})=>getSettings().then(s=>{setSettings({lang:s.lang,theme:s.theme}); document.documentElement.lang=s.lang; document.documentElement.dir=s.lang==='fa'?'rtl':'ltr'}).catch(()=>{})) },[])
  const updateLang = async (lang:Lang)=>{ setSettings(s=>({...s,lang})); document.documentElement.lang=lang; document.documentElement.dir=lang==='fa'?'rtl':'ltr'; await setSetting('lang',lang) }
  const updateTheme = async (theme:ThemeName)=>{ setSettings(s=>({...s,theme})); document.documentElement.setAttribute('data-theme',theme); await setSetting('theme',theme); try{localStorage.setItem('ai-planner-theme',theme)}catch{} }
  return {settings,updateLang,updateTheme}
}

export function AppProvider({children}:{children:ReactNode}) { const {settings,updateLang,updateTheme}=useAppSettings(); return <AppShell lang={settings.lang} theme={settings.theme} onLangChange={updateLang} onThemeChange={updateTheme}>{children}</AppShell> }
