'use client'
import { useEffect,useState } from 'react'
import { Plus } from 'lucide-react'
import { Button, GoalCard, GoalForm, Modal, PageHeader } from '@/lib/ui'
import { deleteGoal,getAllGoals,saveGoal,type Goal } from '@/lib/core'
export default function Goals(){const[goals,setGoals]=useState<Goal[]>([]);const[open,setOpen]=useState(false);async function load(){setGoals(await getAllGoals())}useEffect(()=>{load().catch(console.error)},[]);return <><PageHeader title="اهداف" description="هدف‌های بلندمدت را به قدم‌های کوچک تبدیل کن." action={<Button onClick={()=>setOpen(true)}><Plus size={18}/> هدف جدید</Button>}/><div className="grid grid-3">{goals.map(g=><GoalCard key={g.id} goal={g} onDelete={async x=>{await deleteGoal(x.id);load()}}/>)}</div>{!goals.length&&<div className="empty">هنوز هدف ثبت نشده است.</div>}<Modal open={open} title="هدف جدید" onClose={()=>setOpen(false)}><GoalForm onSave={async g=>{await saveGoal(g);await load()}} onCancel={()=>setOpen(false)}/></Modal></>}
