import Link from 'next/link'
export default function NotFound(){return <main className="splash"><div className="splash-card card"><h1>صفحه پیدا نشد</h1><p className="muted">مسیر موردنظر وجود ندارد.</p><Link className="btn btn-primary btn-md" href="/" style={{marginTop:20}}>خانه</Link></div></main>}
