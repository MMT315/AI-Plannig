import { toGregorian as jalaliToGregorian, toJalaali as gregorianToJalaali, isValidJalaaliDate } from 'jalaali-js'

export type Lang = 'fa' | 'en'
export type ThemeName = 'modern' | 'dark' | 'light' | 'system'
export type Priority = 'low' | 'medium' | 'high' | 'urgent'
export type TaskStatus = 'pending' | 'in_progress' | 'done' | 'cancelled'
export type PlannerType = 'daily' | 'weekly' | 'monthly' | 'yearly'
export type RepeatMode = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly'
export type AlarmType = 'gentle' | 'classic' | 'digital' | 'chime' | 'pulse'
export type AIProvider = 'atria' | 'gapgpt'

export interface Task {
  id: string
  title: string
  description: string
  type: PlannerType
  priority: Priority
  status: TaskStatus
  startDate: string
  startTime: string
  endTime: string
  reminderEnabled: boolean
  reminderMinutesBefore: number
  alarmType: AlarmType
  repeat: RepeatMode
  goalId?: string
  tags: string[]
  createdAt: string
  updatedAt: string
  completedAt?: string
}

export interface Milestone { id: string; title: string; done: boolean; dueDate?: string }
export interface Goal {
  id: string
  title: string
  description: string
  category: string
  targetDate: string
  progress: number
  milestones: Milestone[]
  status: 'active' | 'completed' | 'archived'
  color: string
  createdAt: string
  updatedAt: string
}

export interface CalendarEvent {
  id: string
  title: string
  date: string
  time: string
  allDay: boolean
  color: string
  description: string
  createdAt: string
}

export type HolidayType = 'iranian' | 'international' | 'religious'
export interface Holiday {
  month: number
  day: number
  title: string
  type: HolidayType
  holiday: boolean
}

export interface AIMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: string
}

export interface AIConfig {
  provider: AIProvider
  atriaKey: string
  gapgptKey: string
  model: string
  temperature: number
  personality: 'professional' | 'friendly' | 'motivational' | 'concise'
  memoryEnabled: boolean
}

export interface AppSettings {
  lang: Lang
  theme: ThemeName
  userName: string
  setupComplete: boolean
  notificationsEnabled: boolean
  soundEnabled: boolean
  dndEnabled: boolean
  dndStart: string
  dndEnd: string
  autoBackup: boolean
  ai: AIConfig
}

const DB_NAME = 'ai-planner'
const DB_VERSION = 2
const STORES = ['tasks', 'goals', 'events', 'settings', 'ai_messages', 'activity'] as const
let dbPromise: Promise<IDBDatabase> | null = null

export const DEFAULT_AI_CONFIG: AIConfig = {
  provider: 'atria', atriaKey: '', gapgptKey: '', model: 'Atria-Dawn-Preview',
  temperature: 0.7, personality: 'friendly', memoryEnabled: true,
}

export const DEFAULT_SETTINGS: AppSettings = {
  lang: 'fa', theme: 'modern', userName: '', setupComplete: false,
  notificationsEnabled: true, soundEnabled: true, dndEnabled: false,
  dndStart: '23:00', dndEnd: '07:00', autoBackup: false,
  ai: DEFAULT_AI_CONFIG,
}

function createStore(db: IDBDatabase, name: string) {
  if (db.objectStoreNames.contains(name)) return
  const store = db.createObjectStore(name, { keyPath: 'id' })
  if (name === 'tasks') {
    store.createIndex('startDate', 'startDate', { unique: false })
    store.createIndex('status', 'status', { unique: false })
    store.createIndex('goalId', 'goalId', { unique: false })
  }
  if (name === 'goals') store.createIndex('status', 'status', { unique: false })
  if (name === 'events') store.createIndex('date', 'date', { unique: false })
  if (name === 'ai_messages') store.createIndex('timestamp', 'timestamp', { unique: false })
}

export function initDB(): Promise<IDBDatabase> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) return Promise.reject(new Error('IndexedDB is not supported'))
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      for (const store of STORES) createStore(db, store)
    }
    request.onsuccess = () => {
      const db = request.result
      db.onversionchange = () => db.close()
      resolve(db)
    }
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'))
    request.onblocked = () => reject(new Error('IndexedDB upgrade is blocked by another tab'))
  })
  return dbPromise
}

async function transaction<T>(storeName: string, mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest): Promise<T> {
  const db = await initDB()
  return new Promise((resolve, reject) => {
    let result: T
    const tx = db.transaction(storeName, mode)
    const store = tx.objectStore(storeName)
    const request = run(store)
    request.onsuccess = () => { result = request.result as T }
    request.onerror = () => reject(request.error ?? new Error('IndexedDB request failed'))
    tx.oncomplete = () => resolve(result)
    tx.onerror = () => reject(tx.error ?? new Error('IndexedDB transaction failed'))
    tx.onabort = () => reject(tx.error ?? new Error('IndexedDB transaction aborted'))
  })
}

export const dbGet = <T>(store: string, id: string) => transaction<T | null>(store, 'readonly', s => s.get(id))
export const dbAll = <T>(store: string) => transaction<T[]>(store, 'readonly', s => s.getAll())
export const dbPut = async <T extends { id: string }>(store: string, value: T) => { await transaction(store, 'readwrite', s => s.put(value)) }
export const dbDelete = async (store: string, id: string) => { await transaction(store, 'readwrite', s => s.delete(id)) }
export const dbClear = async (store: string) => { await transaction(store, 'readwrite', s => s.clear()) }

export async function dbClearAll() { for (const store of STORES) await dbClear(store) }

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const item = await dbGet<{ id: string; value: T }>('settings', key)
  return item?.value ?? fallback
}

export async function setSetting<T>(key: string, value: T) {
  await dbPut('settings', { id: key, value })
}

export async function getSettings(): Promise<AppSettings> {
  const [lang, theme, userName, setupComplete, notificationsEnabled, soundEnabled, dndEnabled, dndStart, dndEnd, autoBackup, ai] = await Promise.all([
    getSetting('lang', DEFAULT_SETTINGS.lang), getSetting('theme', DEFAULT_SETTINGS.theme), getSetting('user-name', ''),
    getSetting('setup-complete', false), getSetting('notifications-enabled', true), getSetting('sound-enabled', true),
    getSetting('dnd-enabled', false), getSetting('dnd-start', '23:00'), getSetting('dnd-end', '07:00'),
    getSetting('auto-backup', false), getSetting<Partial<AIConfig>>('ai', {}),
  ])
  return { lang, theme, userName, setupComplete, notificationsEnabled, soundEnabled, dndEnabled, dndStart, dndEnd, autoBackup, ai: { ...DEFAULT_AI_CONFIG, ...ai } }
}

export function uid(prefix = 'id') { return `${prefix}_${Date.now().toString(36)}_${crypto.randomUUID().slice(0, 8)}` }
export function nowISO() { return new Date().toISOString() }
export function isoDate(date = new Date()) { return date.toISOString().slice(0, 10) }

export function toJalali(date: Date) { return gregorianToJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate()) }
export function toGregorian(jy: number, jm: number, jd: number) {
  if (!isValidJalaaliDate(jy, jm, jd)) throw new Error('Invalid Jalali date')
  const g = jalaliToGregorian(jy, jm, jd)
  return new Date(g.gy, g.gm - 1, g.gd)
}
export function jalaliMonthLength(jy: number, jm: number) {
  if (jm <= 6) return 31
  if (jm <= 11) return 30
  return isValidJalaaliDate(jy, 12, 30) ? 30 : 29
}

export const faMonths = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند']
export const faWeekDays = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه']
export const enWeekDays = ['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday']

export function formatJalali(date = new Date(), lang: Lang = 'fa') {
  const j = toJalali(date)
  return lang === 'fa' ? `${faNumber(j.jd)} ${faMonths[j.jm - 1]} ${faNumber(j.jy)}` : `${faMonths[j.jm - 1]} ${j.jd}, ${j.jy}`
}

export function faNumber(value: string | number) { return String(value).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]) }
export function enNumber(value: string | number) { return String(value).replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))) }
export function cn(...values: Array<string | false | null | undefined>) { return values.filter(Boolean).join(' ') }

export const HOLIDAYS: Holiday[] = [
  { month: 1, day: 1, title: 'نوروز', type: 'iranian', holiday: true },
  { month: 1, day: 2, title: 'نوروز', type: 'iranian', holiday: true },
  { month: 1, day: 3, title: 'نوروز', type: 'iranian', holiday: true },
  { month: 1, day: 4, title: 'نوروز', type: 'iranian', holiday: true },
  { month: 1, day: 12, title: 'روز جمهوری اسلامی ایران', type: 'iranian', holiday: true },
  { month: 1, day: 13, title: 'روز طبیعت', type: 'iranian', holiday: true },
  { month: 2, day: 1, title: 'روز کارگر', type: 'international', holiday: true },
  { month: 3, day: 14, title: 'رحلت امام خمینی', type: 'iranian', holiday: true },
  { month: 3, day: 15, title: 'قیام ۱۵ خرداد', type: 'iranian', holiday: true },
  { month: 6, day: 31, title: 'روز صنعت چاپ', type: 'iranian', holiday: false },
  { month: 7, day: 1, title: 'بازگشایی مدارس', type: 'iranian', holiday: false },
  { month: 9, day: 30, title: 'شب یلدا', type: 'iranian', holiday: false },
  { month: 10, day: 1, title: 'روز مادر و زن', type: 'iranian', holiday: false },
  { month: 11, day: 22, title: 'پیروزی انقلاب اسلامی', type: 'iranian', holiday: true },
  { month: 12, day: 29, title: 'روز ملی شدن صنعت نفت', type: 'iranian', holiday: true },
]

export function getHolidaysFor(jy: number, jm: number, jd: number) {
  return HOLIDAYS.filter(h => h.month === jm && h.day === jd)
}

export async function getTasksForDate(date: string) {
  const tasks = await dbAll<Task>('tasks')
  return tasks.filter(t => t.startDate === date).sort((a, b) => (a.startTime || '99:99').localeCompare(b.startTime || '99:99'))
}
export async function getAllTasks() { return dbAll<Task>('tasks') }
export async function getAllGoals() { return dbAll<Goal>('goals') }
export async function getAllEvents() { return dbAll<CalendarEvent>('events') }
export async function saveTask(task: Task) { await dbPut('tasks', task) }
export async function saveGoal(goal: Goal) { await dbPut('goals', goal) }
export async function deleteTask(id: string) { await dbDelete('tasks', id) }
export async function deleteGoal(id: string) { await dbDelete('goals', id) }

export function newTask(partial: Partial<Task> = {}): Task {
  const now = nowISO()
  return { id: uid('task'), title: '', description: '', type: 'daily', priority: 'medium', status: 'pending', startDate: isoDate(), startTime: '', endTime: '', reminderEnabled: false, reminderMinutesBefore: 10, alarmType: 'gentle', repeat: 'none', tags: [], createdAt: now, updatedAt: now, ...partial }
}
export function newGoal(partial: Partial<Goal> = {}): Goal {
  const now = nowISO()
  return { id: uid('goal'), title: '', description: '', category: 'عمومی', targetDate: '', progress: 0, milestones: [], status: 'active', color: '#7c5cff', createdAt: now, updatedAt: now, ...partial }
}

const AI_ENDPOINTS: Record<AIProvider, string> = {
  atria: 'https://api.atria-asi.ai/v1/chat/completions',
  gapgpt: 'https://api.gapgpt.app/v1/chat/completions',
}

function aiSystemPrompt(config: AIConfig) {
  const personality = { professional: 'حرفه‌ای و دقیق', friendly: 'صمیمی و کمک‌کننده', motivational: 'انگیزشی اما واقع‌گرا', concise: 'کوتاه و مستقیم' }[config.personality]
  return `تو دستیار برنامه‌ریز شخصی AI Planner هستی. پاسخ‌ها باید ${personality} باشند. زبان پیش‌فرض فارسی است. برای ساخت/ویرایش وظیفه یا هدف، ابتدا اطلاعات لازم را از کاربر بپرس و بدون تأیید کاربر عملیات مخرب انجام نده.`
}

export async function chatWithAI(config: AIConfig, messages: Array<Pick<AIMessage, 'role' | 'content'>>, signal?: AbortSignal) {
  const key = config.provider === 'atria' ? config.atriaKey : config.gapgptKey
  if (!key) throw new Error('کلید API برای سرویس انتخاب‌شده تنظیم نشده است.')
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), 30000)
  const abortHandler = () => controller.abort()
  signal?.addEventListener('abort', abortHandler, { once: true })
  try {
    const response = await fetch(AI_ENDPOINTS[config.provider], {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: config.model, temperature: config.temperature, messages: [{ role: 'system', content: aiSystemPrompt(config) }, ...messages] }),
      signal: controller.signal,
    })
    if (!response.ok) {
      const text = await response.text().catch(() => '')
      throw new Error(`AI request failed (${response.status})${text ? `: ${text.slice(0, 240)}` : ''}`)
    }
    const data = await response.json() as { choices?: Array<{ message?: { content?: string } }> }
    const content = data.choices?.[0]?.message?.content
    if (!content) throw new Error('پاسخ معتبر از سرویس هوش مصنوعی دریافت نشد.')
    return content
  } finally {
    window.clearTimeout(timer)
    signal?.removeEventListener('abort', abortHandler)
  }
}

export async function testAIConnection(config: AIConfig) {
  try {
    await chatWithAI(config, [{ role: 'user', content: 'فقط بنویس: اتصال موفق است.' }])
    return { ok: true, message: 'اتصال موفق بود.' }
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : 'خطای ناشناخته' }
  }
}

export async function saveAIMessage(message: AIMessage) { await dbPut('ai_messages', message) }
export async function getAIMessages() { return (await dbAll<AIMessage>('ai_messages')).sort((a, b) => a.timestamp.localeCompare(b.timestamp)) }
export async function clearAIMessages() { await dbClear('ai_messages') }

let audioContext: AudioContext | null = null
export function playSound(type: AlarmType = 'gentle') {
  if (typeof window === 'undefined') return
  try {
    audioContext ??= new AudioContext()
    if (audioContext.state === 'suspended') void audioContext.resume()
    const ctx = audioContext
    const oscillator = ctx.createOscillator()
    const gain = ctx.createGain()
    const frequencies: Record<AlarmType, number> = { gentle: 660, classic: 880, digital: 1046, chime: 523, pulse: 740 }
    oscillator.frequency.value = frequencies[type]
    oscillator.type = type === 'digital' ? 'square' : 'sine'
    gain.gain.setValueAtTime(0.0001, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.02)
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35)
    oscillator.connect(gain).connect(ctx.destination)
    oscillator.start()
    oscillator.stop(ctx.currentTime + 0.36)
  } catch (error) { console.warn('[audio]', error) }
}

export async function requestNotifications() {
  if (typeof Notification === 'undefined') return 'unsupported' as const
  return Notification.requestPermission()
}

export function isDNDActive(start: string, end: string, date = new Date()) {
  const current = date.getHours() * 60 + date.getMinutes()
  const [sh, sm] = start.split(':').map(Number)
  const [eh, em] = end.split(':').map(Number)
  const s = sh * 60 + sm, e = eh * 60 + em
  return s <= e ? current >= s && current < e : current >= s || current < e
}

let scheduler: number | null = null
export function startAlarmScheduler() {
  if (typeof window === 'undefined' || scheduler !== null) return
  const check = async () => {
    try {
      const settings = await getSettings()
      if (!settings.notificationsEnabled || (settings.dndEnabled && isDNDActive(settings.dndStart, settings.dndEnd))) return
      const now = new Date()
      const tasks = await getTasksForDate(isoDate(now))
      for (const task of tasks) {
        if (!task.reminderEnabled || task.status === 'done' || !task.startTime) continue
        const [h, m] = task.startTime.split(':').map(Number)
        const reminderAt = new Date(now)
        reminderAt.setHours(h, m - task.reminderMinutesBefore, 0, 0)
        const delta = now.getTime() - reminderAt.getTime()
        const key = `ai-planner-notified-${task.id}-${isoDate(now)}`
        if (delta >= 0 && delta < 60000 && !sessionStorage.getItem(key)) {
          sessionStorage.setItem(key, '1')
          if (settings.soundEnabled) playSound(task.alarmType)
          if ('Notification' in window && Notification.permission === 'granted') new Notification(task.title || 'یادآوری وظیفه', { body: `${task.reminderMinutesBefore} دقیقه تا شروع`, icon: '/icons/icon-192.png' })
        }
      }
    } catch (error) { console.warn('[scheduler]', error) }
  }
  void check()
  scheduler = window.setInterval(check, 30000)
}
export function stopAlarmScheduler() { if (scheduler !== null) { window.clearInterval(scheduler); scheduler = null } }

export async function exportAllData() {
  const data = { version: DB_VERSION, exportedAt: nowISO(), tasks: await dbAll<Task>('tasks'), goals: await dbAll<Goal>('goals'), events: await dbAll<CalendarEvent>('events'), settings: await dbAll<{ id: string; value: unknown }>('settings'), ai_messages: await dbAll<AIMessage>('ai_messages') }
  return JSON.stringify(data, null, 2)
}

export async function importAllData(json: string) {
  const data = JSON.parse(json) as { tasks?: Task[]; goals?: Goal[]; events?: CalendarEvent[]; settings?: Array<{ id: string; value: unknown }>; ai_messages?: AIMessage[] }
  const lists: Array<[string, unknown[] | undefined]> = [['tasks', data.tasks], ['goals', data.goals], ['events', data.events], ['settings', data.settings], ['ai_messages', data.ai_messages]]
  for (const [store, list] of lists) if (Array.isArray(list)) for (const item of list) await dbPut(store, item as { id: string })
}
